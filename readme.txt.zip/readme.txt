dir google
    code for scraping and voice automating google.com
dir wiki
    code for querying the wiki api for text and summaries of their articles.
    Code also to load and run the bert model for question answering
dir mail
    code to voice automate gmail.com
stt.py, tts.py
    util files for speech to text and text to speech functions
chromedriver
    the chrome browser driver used by selenium to automate web browsing
main.py
    main file which calls all the other functions

Running instructions: 
1. The user will open the terminal using voice assistant in his laptop
2. The user will then navigate to the site of file and run the program by using the shortcuts set initially i.e. python main.py 
3. Once the program is run the user has to simply input his/her search query and enjoy the browsing experience